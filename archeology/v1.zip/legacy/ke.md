# ke
- préfixe **caché par**

Se prononce “ké”. Par exemple
la **langue** se dit *keli* (caché par la bouche)
le **clitoris** *keyon* (caché par la vulve)
les **testicules** *kebaj* (caché par les jambes)  
l’**anus** se dit *kepal* (caché par les fesses)

> Keli haftar       **Lèche mon gland**
> Keli keyon        **Lèche mon clitoris**