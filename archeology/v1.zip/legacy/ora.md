# ora
- corps **excitation, envie**
- position **s'oublier**
- adjectif **excitant**
- langue **interrogation**

Bien plus que l'orgasme, *ora* désigne le voyage, le mouvement. Comparé à *oda* (potentiel), *ora* représente l’excitation, l’élan. Une interrogation avec *ora* est équivalente à **tu veux vivre ce voyage ?**.

> Ora ? **Quelle est la profondeur de ton voyage ?**
> A ora li tar ? **À cette personne, tu aimerais sucer le pénis ?**
> Gais ora. **Sens ton envie, ton voyage.**
> E ora. **Soit ton voyage, oublies-toi.**
> A: A moonoda ora li yon ?  
> B: Ora dom.  
>   **A: À la personne aux seins, ça t’excite de sucer la vulve ?**  
>   **B: très excitant (oui beaucoup).**

On peut aussi désigner la force d’une excitation avec *ora*:

> Oratar dom. **Grosse érection phallique.**
> Orayin menu. **Douce excitation vaginale.**