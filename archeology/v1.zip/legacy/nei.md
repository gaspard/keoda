# nei
- adjectif **joli**

Littéralement **qui n'est pas soi, qui s'oublie**.

> Neihem. **Mon joli, ma jolie.**