# z kepal
- corps **anus**
- verbe **prendre dans l'anus**

Littéralement "caché par les fesses".

> Kepal hafma   **Mets moi doigt dans ton anus**
> O taro kepal  **On frappe ton anus avec notre pénis**