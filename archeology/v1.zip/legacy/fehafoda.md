# fehafoda
- chose **habits du haut**

Ce qui couvre le buste, le haut du corps.

> E ne fehafoda. **Soit torse nu.**