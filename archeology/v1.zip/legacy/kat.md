# kat
- position **à quatre pattes**

Voir aussi la position *moon* (sur les seins) qui est une variante avec l’arrière-train encore plus offert.

> E kat im. **à quatre pattes les fesses sérées.**
> E kat om. **à quatre pattes les fesses écartées.**
> E moon om. **le buste au sol, les fesses en l’air écartées.**