# e
- verbe **deviens**, **soit**, **être**

Ce verbe est utilisé pour imposer une position et doit être compris comme “deviens cette position”. Une position implique beaucoup plus qu’une simple posture: c’est une disponibilité, une manière d’être.

> E kat.             **Soit à quatre pattes.**
> E bo im.           **Soit sur le ventre, les jambes serrées.**
> E od sat hafbaj olom.  
> 	**Soit sur le dos, pieds contre cuisses, jambes ouvertes,  
> 	  sexe écarté par une main.**

Lorsque le sujet n’est pas la personne qui reçoit l’ordre, le verbe devient **être**, et non pas **soit**.

> Toda e ora.	**La personne avec un pénis est excitée.**
> Yun e loi.	**Ma vulve est humide.**
> I tar e loi.  **À toi, le pénis est humide.**

Voir aussi `ba` (danser).