# u
- suffixe **tirer**
- langue **sujet tiré de la phrase d’avant**

Implique une action de traction, de pincement.

> Yinu tar.     **Tire sur mon pénis avec ton vagin.**
> Mu hafmoon.   **Tire sur mes tétons avec tes mains.**

On peut aussi utiliser *u* comme sujet ou receveur d’un geste pour éviter de répéter sans cesse les mêmes adresses:

> A faoda fa moon. I fa u. **À la personne qui regarde, montre tes seins. Regarde cette personne.**
> Yoda rao djiloda. Au olir gais i tar yun dom. **La personne avec une vulve aime la personne avec des cheveux.  J’aimerais que tu la (yoda) pénétre bien fort.**