# intentions
- langue

Cette langue doit être utilisée pour baiser plus et mieux. Le mode interrogatif répond aux jeux liés à l'anticipation et à la peur. Ce n'est en aucun cas une manière de réclamer quelque chose en le demandant. Pour réclamer une position, un cunnilingus, des pénétrations plus douces ou violentes, on ordonne *tar yin odom* (baise-moi fort).

De ce fait, cette langue, à part quand elle est utilisée pour questionner le désir en public (tu ferais ça à cette personne ?) doit être affirmée de manière forte et puissante.

De ce fait, on veillera toujours à avoir des "safe words", tels que définit dans le milieu BDSM. Ce cadre offre à la fois plus de sécurité et plus de liberté.

Cette langue n'est pas pour les pauvres chéris et autre mollusques sans gratitude.