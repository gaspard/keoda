# grammaire
- langue

Une phrase est composée:

1. **à qui** est définit en utilisant *i* (à toi-même) ou *a* suivi de la personne (*a yoda ud*). La version par défaut *o* (à moi) n'est pas dite sauf en cas de phrase enchâssée (aimer "faire quelque chose" par exemple).
2. **sujet** (sans rien, c'est "tu"). Peut être *o* ("on", "je" n'existe pas) ou une indication de personne (*...oda*)
3. **futur** ajout de *..lir* après le sujet (*todalir* il va)  
	**passé** ajout de *..lem* après le sujet (*todalem* il a)
4. (on pose une question avec *ora*, *oda* ou encore *do*)
5. **verbe** tenant compte des suffixes *o*, *u*, *i*
6. **(sur) quoi** (peut être une autre phrase pour dire **aimer faire quelque chose**)
7. **comment** adjectif
8. **, nom** compliment, injure

La forme *I o* (à toi, je) est abbrégée en *Io*.

> (1) I (2,3) todalir (5) tar (6) yin (7) odom.  
> **à toi      il va   pénétrer  le vagin bien fort.**
> (1) A yoda (3) lir (5) li (6) yon.  
> **à elle  tu vas   sucer  la vulve.**
> (1) A yoda ud (2,3) olir (5) mo (6) yon (7) melo.  
> **à elle en face je vais tapper sur la vulve doucement.**
> (2,3) Yodalir li tar.  
> **(à moi) elle va sucer le pénis.**
> (1) A toda (4) ora (5) li (6) tar ?  
> **(à lui) tu veux sucer le pénis ?**
> (1) I (2,3) toda (4) oda (5) tar (6) yin (7) menu ?  
> **(à toi) tu aimerais éventuellement qu'il pénètre ton vagin  
>  délicatement ?**
> (2) Toda (5) e (7) ora.  
> **La personne avec un pénis est excitée.**
> (2) Omgatar (5) rao (6) yinom.
> **Shiva aime le vagin sacré.**
> (1) O (2) o (4) mi (5) moon.  
> **Je me masse les seins.**
> (4) Odu (5) sen, (8) lesoda lil.  
> **Viens ici, petite pute.**

Questions

> Ora li tar ?         **Désires-tu me sucer le pénis ?**
> A yoda ora la yun ?  **Désires-tu lui embrasser la vulve ?**
> Do gais mu ?         **Es-tu fatigué ?**
> A toda oda mi bo ?   **Avec lui, tu pourrais caresser son ventre ?**

Phrases enchâssées:

> O ora o o mi moon.  
> **Ça m'excite de me masser les seins.**
> O ora oi mi moon.  
> **Ça m'excite comme tu me masses les seins.**
> O ora io mi moon.  
> **Ça m'excite de te masser les seins.**
> O ora i i mi moon.  
> **Ça m'excite comme tu te masses les seins.**