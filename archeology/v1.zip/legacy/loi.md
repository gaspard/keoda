# loi
- adjectif **humide**

Se prononce « lo i ».

> Yoda e loi.		**Elle est humide.**
> Olir li yun loi.	**Je vais sucer ta vulve humide.**