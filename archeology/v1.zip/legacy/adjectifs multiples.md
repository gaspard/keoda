# adjectifs multiples
- langue

Lorsqu'on utilise plusieurs adjectifs, on mettra toujours les plus génériques (quantité, manière) à la fin. Par exemple:

> E fen feo om.  **Soit à genoux, sur moi, ouverte.**
> Mi moon rao menu. **Caresse mes seins tendrement et délicatement.**