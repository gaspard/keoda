# Ahi
- suffixe **encore**
- todo: corriger "ahhh" dans les exemples.


Permet de féliciter la personne soumise pour sa tâche tout en lui demandant de continuer.

Le « h » est marqué par un son de gorge.

> Ahi.     **Encore.**
> Ahi dom. **Encore à fond.**
> Li ahi.  **Suce encore.**