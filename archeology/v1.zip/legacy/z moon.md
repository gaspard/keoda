# z moon
- corps **seins**
- position **à genoux, buste au sol.**

Le téton se dit *hafmoon*.

> La hafmoon dom. **Embrasse-moi les tétons bien fort.**
> Imi moon menu. **Caresse-toi les seins en effleurant.**