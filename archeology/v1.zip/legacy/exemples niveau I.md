# exemples niveau I
- langue

Phrases simples au présent.

> Li tar.
> I mi moon menu.
> E moon pal om.
> E fen feo em yinu tar.
> A toda odu ud.
> Faodalem peu.
> Lesoda hem.
> E pal tole om sat fe kiss.
> Yuda yun la.
> A mu djil, gayun.
> Neo mu gais.
> E djil, gadur.
> Corao, gafo ihem.
> Kegais sente.