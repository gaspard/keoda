# djil
- corps **cheveux**
- préfix **poil** (on utilise alors *dji* sans le l.
- position **debout, penché(e) en avant, les cheveux offerts pour être pris par la main (*ma djil*) et emmené(e).**

On a aussi *djiud* **barbe** (cheveux devant) et *djitar* ou *djiyon*, etc.

> E djil            **Mets-toi debout les cheveux offerts**

## E djil

On avait invité des amis à manger à la maison. On avait préparé toute une série de plats indiens qui cuisaient lentement en dégageant des odeurs qui m’emmenaient dans des souvenirs d’Inde. J’étais là, à révasser à côté du poêle quand j’ai remarqué que Natasha avait mis son collier de soumise.

J’étais surpris parce qu’on avait absolument rien prévu ou même négocié avec ces amis en termes de jeux sexuels. Je sentais cette provocation comme une sorte de test: saurais-je jouer correctement avec cette situation imprévue ?

J’écoutais distraitement la discussion qui tournait sur les candidats à l’élection du monarque français. Natasha participait à la discussion comme si de rien n’était. Tout mon corps commençait à se tendre et je voyais que ma soumise s’amusait de son petit tour.

J’observais le couple d’amis qui mangeait des olives et parlait de manière détendue de politique et me demandais ce que ma soumise avait en tête. Nos amis étaient ouverts d’esprits et on jouait de temps en temps à se complimenter les uns les autres sur nos allures mais de là à enclencher une scène avec eux, juste là ?

C’est alors que j’ai décidé de renversé le rapport de force et de jouer avec la situation. Natasha était en pleine discussion et au milieu d’une de ses phrases, je m’exclamai sur ce ton un peu dur et froid que j’utilise pour la soumettre:

> E djil.

Instantanément, elle s’est tue et se déplaçant lentement comme elle a si bien appris à le faire, consciente de chaque geste, de chaque mouvement du corps, elle vient se positionner au milieu du salon et, lentement, elle penche son buste en avant, laissant ses cheveux pendre devant son visage, cambrant légèrement le dos pour mettre en valeur ses fesses et la puissance de son dos. Elle est très belle dans cette lenteur, ce tonus *Odahem*.

Je lui dis alors:

> A todalir lakebaj menu em i yodalir moyon.

J’imagine la scène si je lui donnais l’ordre de s’exécuter, Natasha, toujours penchée en avant, les fesses dégagées. Je la tiens par les cheveux pendant qu’embrasse doucement les testicules de notre ami et que son épouse frappe Natasha sur la vulve.

La scène m’excite mais bien sûr, on a rien négocier et nos amis sont déjà surpris de voir Natasha habillée penchée en avant. Selon l’angle où l’on se trouve, on peut faufiller son regard dans son décolleté mais c’est encore  très sobre tout ça.

Je me lève et viens me tenir debout, à côté de sa tête. Tout en caressant les cheveux de Natasha, je regarde nos amis très attentifs tout à coup et je leur dit: «Je vous présente Natasha, soumise pour nous servir.». Puis je dis à Natasha, pour prouver son obéissance:

> E fen lo.

Je la veux à genoux, soumise, la tête penchée en avant pour éviter qu’elle croise le regard des autres et qu’elle perde sa belle concentration. Je la sens un peu fébrile, elle pense peut-être qu’enfiler ce collier était une mauvaise idée. Je ne veux pas la laisser partir dans ses pensées alors je lui dis d’un ton confiant et fort qui implique que j’assume la situation:

> Nedon.

Et je continue ma présentation: «On va la laisser un moment comme ça pendant que nous discutons de cette situation et des envies de chacun. Ce qui est agréable avec une soumise, c’est qu’on lui doit rien: il n’y a donc aucune pression à ce qu’on décide quelque chose rapidement où que l’on fasse quoi que ce soit. Vous voulez encore de la bruschetta ?». Mes amis, un peu confus et amusés me réponde que oui, pourquoi pas. J’envoie donc Natasha nous préparer ça pour la mettre un peu en mouvement:

> Don **bruschetta** odahem.

Natasha se lève avec grâce et lenteur. Je sens qu’elle est concentrée malgré son coeur qui tappe et fait trembler ses tétons contre son chemisier. Je la trouve très appétissante et je crois que nos deux invités se disent un peu la même chose au milieu de la tornade de pensées qui doit les envahir en ce moment.

Notre amie est la première à prendre la parole: «Je savais qu’elle allait mettre son collier. On en avait parlé avant.» Comment ?! Je suis furieux. Ma soumise ne m’a rien dit. Elle m’a manipulé. J’ai envie qu’elle se retrouve nue, les fesses en l’air pour recevoir la fessée. J’hésite juste avant de la rappeler et de lui dire:

> E moon ne feoda. Olir fo pal.

Et je me ravise. L’imaginer dans cette position m’excite beaucoup mais je sais aussi qu’elle s’y attend un peu et j’ai envie de prendre le temps. Je respire profondément et alors que Natasha revient avec la bruschetta, je lui dis simplement d’enlever son soutiens-gorge et de se remettre en position:

> Ne femoon em e fen lo.

Pendant que Natasha enlève son sous-vêtement tout en gardant son chemisier, nous reprenons la discussion en la regardant du coin de l’oeil. Ses tétons bougent contre le tissus délicat avec sa respiration et révèlent le côté pulpeux de ses beaux seins. On sent la tension sexuelle monter doucement. Je regarde notre amie dans les yeux, la fixe un moment puis me tourne vers son homme et lui dit: «Et toi, ça te va, ce petit jeu ? Tu connais les règles ?». Notre ami, en souriant me répond qu’il est assez joueur mais qu’il aimerait effectivement connaître les règles de ce petit jeu.

Je dis alors à Natasha:

> E sat nefa lo. Ne feyon menu.

Et pendant qu’elle se lève les yeux fermés et enlève tout doucement sa culotte, j’explique à nos amis: «La soumise n’obéit qu’à moi. Les safe-words sont “jaune” pour une demande de ralentissement et “rouge” pour l’arrêt de la scène. Si l’un d’entre nous quatre ne se sent pas bien avec ce jeu, à tout moment il peut utiliser un des safe-words et dire “jaune” (on fera alors une pause pour discuter) ou “rouge” (on arrête tout et on passe à table). Cette histoire se passe ensemble ou pas du tout. Finalement il vous faut savoir que les personnes qui sont en contact physique avec la soumise doivent m’obéir en lien avec ce contact. Alors que vous la caressez, je peux par exemple vous demander de le faire plus doucement ou plus fort mais je ne peux pas vous demander de préparer la bruschetta ou de vous mettre nu. Vous ne pouvez pas non-plus avoir d’initiatives avec la soumise sans passer par mon approbation qui peut se faire par un échange de regards. Des questions, des envies ?»

Natasha est debout, le buste bien droit, la tête penchée en avant, les yeux toujours clos. Ses tétons fiers nous fixent du regard sous son chemisier. Sa jupe courte dessine le début de ses cuisses. Elle tient sa culotte dans sa main droite. J’en profite pour dire:

> Ne ma feyon. I mi moon if feoda menu.

Elle lâche sa culotte par terre et pendant qu’elle se caresse doucement les seins sous son chemisier, je me lève et dis: 

> Haflem od.

Pendant que je prends deux foulards qui traînaient sur une chaise, Natasha joint ses avant-bras dans le dos se qui lui fait bomber un peu le torse. Elle est sculpturale dans cette position… Je m’approche et lui attache les bras. Avant de lui mettre le foulard et pour m’assurer qu’elle ne risque pas de tomber et de se blesser:

> E fen. Haf fa.

Elle se met à genoux et me présente sa tête. Je joue un peu avec ses cheveux et lui mets le bandeau sur les yeux pour qu’elle parte un peu plus loin dans cette réalité parallèle où elle est esclave et soumise. Je déboutonne son chemisier pour augmenter le décolleté mais garde les deux derniers boutons. J’aime ce triangle de chair dessiné par la blancheur du chemisier. Ça dessine une pointe qui nous fait glisser entre ses seins pour atterrir vers son pubis caché par la jupe. Je relève la jupe juste assez pour libérer ses genoux mais pas trop afin de ne pas montrer l’intérieur de ses cuisses.

> E fen om.

Elle écarte les genoux, je baisse un peu la lumière. Nos amis sont assis sur le canapé *A toda yoda mi tar feoda.*, elle caresse le sexe de son homme par-dessus son pantalon pendant qu’il observe Natasha attachée au sol. Je montre de la main ce sexe encore caché et je dis à ma soumise:

> Li om.

Elle ouvre la bouche et notre ami comprend l’invitation. Il se lève en silence pendant que je m’assied avec son amie et que nous observons la scène. Il s’avance, ouvre son pantalon et sort un beau sexe un peu gonflé *Oratar menu* qu’il avance lentement vers le visage de Natasha. Il lui caresse les lèvres avec son sexe *Tar la* puis celui-ci durcissant doucement, il le plonge un peu dans sa bouche offerte *Tar li*. Je dis alors:

> Li tar. Gais ora.

Avec notre amie, nous regardons la scène un peu excités et amusés. Je crois qu’il est temps que l’on révèle le sexe de Natasha:

> E fen odom.

Elle écarte bien large se genoux et en montrant la main de notre amie je l’invite à *A yoda mi yon*… Elle se lève et vient se poser derrière la soumise et la plaque contre elle. D’une main elle glisse sous le chemiser et lui attrape un sein et de l’autre elle se met à lui caresser la vulve et le clitoris *keyon*. Notre ami se retrouve avec deux visages de femmes tout proches de son sexe et en profite pour passer d’une bouche à l’autre ce qui ravit sa compagne.

> A yoda la la em a toda li tar.

Natasha cherche alors la bouche de son amie pour l’embrasser entre deux tétées à ce gros sexe encore inconnu il y a peu. J’observe la scène de loin et trouve le tableau assez réussi. Je mets un peu de musique et allume quelques bougies.

> E moon om.

Natasha se penche alors en avant, utilisant se genoux bien écartés et sa souplesse de chat pour venir poser ses seins au sol. Je place un coussin sous son visage. Elle a le cul dressé et son amie lui masse la vulve par derrière maintenant tout en continuant de rassurer le grand membre de son ami qui semble craindre les moindres changements d’atmosphère. Je prends du lubrifiant et m’en met une bonne dose sur la main avant de venir humidifier encore plus la vulve bien juteuse de Natasha. Jouant un peu sur l’emplacement des bougies, je mets en valeur la forme rebondie de son cul ainsi que le dessin sombre de sa vulve. Je me lève et vais chuchoter à l’oreille de notre amie: «Je crois que Natasha aimerait beacoup embrasser ta vulve.» Elle se lève, ôte sa jupe et sa culotte et vient se poser tout contre le visage plaqué au sol de la soumise.

> A yoda la yun. Olir tar yun.

D’un geste de main, je donne un préservatif à notre ami, l’invitant par là à baiser le cul dressé de Natasha. Il approche son sexe dur de la vulve humide et ouverte et pose ses mains possessives sur les hanches. Il tient ce cul de tout son être. D’un geste de main je lui fait signe d’y aller très lentement, centimètre par centimètre jusqu’à ce qu’il soit très profondément en elle et là je lui dis de ne plus bouger. Je sens que mes indications chorégraphiques l’agacent, qu’il voudrait baiser comme il l’entend. Mais c’est la règle du jeu et j’en suis le maître. Je veux qu’il attende.

Je m’approche de sa compagne et lui demande du regard si je peux lui caresser la vulve. Elle acquiesce et pendant que je la caresse, je fais comprendre à son homme qu’il doit suivre le rythme de ma main dans le cul de Natasha. Cette dernière sent les mouvements coordonnés de ma main et du sexe qui bouge lentement en elle. J’approche ma bouche de l’oreille de notre amie et lui demande si elle a envie que je la prenne comme son homme prend Natasha *Do olir tar yun e moon ?* Elle murmure un oui rauque, comme essouflée et se pose les fesses en l’air. Elle est un peu loin pour que son homme profite pleinement du moment où je vais la pénétrer et je lui demande doucement de mettre son cul à côté de Natasha.

> A yoda la la.

Natasha approche sa bouche et les deux filles s’embrassent pendant que je mets une capotte sur mon sexe déjà bien excité. Je regarde ce nouveau cul à côté de celui de ma soumise. J’en admire les formes plus anguleuses, la vulve un peu plus rouge et quasi sans poils. Je caresse ce sexe avec du lubrifiant. J’aime quand c’est très doux et humide. Je lui écarte un peu les genoux pour l’amener juste à la bonne hauteur pour mon confort. Je demande à notre ami à haute voix de faire exactement comme moi.

Les filles sentent alors chaque geste sur elle-même ainsi que l’effet sur leur amie qui râle, la bouche humide.

> A yoda olir mo pal em tar yin odom.

Je donne la couleur pour Natasha puis elle sent les mains de l’homme contre ses fesses qui lui écarte bien fort les fesses puis entre et sort avec de grand mouvement amples. Je sens que nos amies sont mûres et je pense que nous pouvons les soumettre au sol (ce qui rendra les pénétrations un peu moins profondes). Si mon ami a aussi une verge qui s’allonge avec l’excitation, je ne veux pas que ça devienne désagréable pour nos amies.

> E bo odom yin tar.

Natasha se couche lentement sur le ventre en étendant les jambes, tout en aspirant le sexe de notre ami avec son vagin. Je sens qu’elle est soulagée de lâcher l’effort pour garder les fesses en l’air ainsi que la tension qui s’accumulait dans ses épaules. Son amie l’imite et je me retrouve à califourchon sur son cul. Je lui attrape la nuque et la plaque au sol *A yoda mo dur*. En la tenant comme ça, mon sexe profondément en elle, je m’approche de son oreille et lui demande: «Ton ami nous regarde (petit coup de queue assez profond) et moi j’ai envie de te baiser comme une chienne. Tu sais qu’il va faire la même chose avec Natasha. Tu veux ?» Elle articule à peine un oui rauque.

Je focalise alors sur cette amie en laissant les autres se débrouiller. Je me colle à son oreille et lui fait synchroniser sa respiration sur la mienne pour qu’elle ralentisse. Je la fait rouler sur le côté avec une jambe en l’air pour que son sexe soit bien visible. Je la baise lentement en la contenant de mes grands bras. Je cherche les angles et pressions auxquelles sont corps réagit. Je découvre qu’elle aime être tenue et en même temps elle a besoin de bouger le bassin. Je m’assied en lotus et l’amène sur moi. Je veux sentir son ventre contre le mien, sentir ses seins, voir son visage. J’enlève ses habits et l’arrête dans ses mouvements quand elle veut accélérer. Je ne veux pas qu’on jouisse. Je veux que ça dure.

Natasha et notre ami ont fait des bruits de bêtes et son partis se doucher. On reste quasi immobiles à respirer ensemble en s’embrassant à peine. Je commence à chanter tout doucement en berçant mon amie dans mes bras, autour de mon sexe, contre mon épaule. On danse du bassin à la tête en chantant doucement. J’arrive dans cet état que j’adore où mon corps est sexuellement très excité et où il sait exactement comment bouger pour garder cette force et la faire voyager. Nos têtes s’éteignent. On est deux salopes, puissantes danseuses de la force de vie. Mon serpent s’enroule autour de sa colonne nous sommes sombres et lumineux, tristes et joyeux, vivants et morts.

Natasha et notre ami reviennent de la douche tout nus et se posent naturellement contre nous, Natasha dans mon dos, l’ami contre le dos de son amie. Doucement, il nous remettent en mouvement. C’est comme si Natasha faisait l’amour à cette amie à travers moi et comme si mon ami me caressait à travers son amie. Je sens que Natasha veut faire jouir son amie. Elle pose ma main contre ses hanches que j’empoigne et lui tenant la nuque. J’ai l’impression qu’on est tous les trois en train de baiser cette fille accroupie sur moi. Je devies plus sombre, je veux la détruire. Elle s’abandonne à ma noirceur. Je lui mord le trapèze en lui pinçant un téton. Je lui soulève une cuisse, son ami la tient en équilibre et Natasha lui tient la jambe en l’air. Elle se met à crier, gémir et pleurer, un peu tout en même temps. Je me laisse emporter et sens le dragon monter. Natasha me retient et me souffle doucement dans le cou. Je m’adoucis et m’abandonne dans les bras de mon amie encore toute humide de toutes ses humeurs.

Je suis couché en avant, les fesses à l’air et Natasha sur un coup de tête se met à m’enduire l’anus de lubrifiant en disant *Olir tar kepal.* J’ai peur, je ne sais plus qui je suis, j’ai perdu le refuge de mon dragon, j’ai envie de pleurer. Mon amie me prend dans les bras et me cajole pendant que Natasha et mon ami (je les soupçonne d’avoir prévu la chose) me massent le sexe et l’anus. Je suis encore très excité et je découvre qu’être pris comme un bébé dans les bras me bouleverse profondément.

Je sens un sexe dur contre mes fesses. Natasha me plaque au sol et m’appuie sur une fesse avec le coude tout en me pinçant très fort la nuque. Ça fait mal, je n’arrive plus penser. Je glisse sur le corps de mon amie et me réfugie entre ses jambes, le nez contre son sexe pour qu’il me raconte la peur, la jouissane, l’abandon et le pouvoir d’être pris. *Odahem*.