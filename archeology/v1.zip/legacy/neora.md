# neora
- adjectif **sans excitation**

De *ne* (sans) et *ora* (désir, excitation).

> A: A toda ora li tar ?
> B: Neora.  
> 	**A: À lui, ça t’exciterait de sucer le pénis ?**  
> 	**B: Sans excitation (pas du tout).**