# z tar
- corps **pénis**
- verbe **pénétrer avec le pénis**

Avec le suffixe *o*, ça devient *taro* (**frapper du pénis**). Avec *oda*, on a *toda* (**personne avec un pénis**). Le gland se dit *haftar*.

> Tar yin.  **Pénètre avec ton pénis dans mon vagin.**
> Taro yon. **Frappe ma vulve avec ton pénis.**
> Ma tar.   **Masturbe mon pénis avec la main.**
> I mi tar. **Caresse-toi le pénis.**