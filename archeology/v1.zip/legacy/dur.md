# dur
- corps **nuque**
- verbe **se soumettre**

Se prononce « dour ». L’utilisation de *dur* implique l’exécution des ordres après l'anticipation d'une série d'ordres avec le suffixe *lir*.

> Olir ma dur.  **On va t’attraper la nuque.**
> Dur.          **Soumets-toi, obéis.**
> Elir kat om. A lilir tar em o tar yin ... Dur.  
>   **Tu vas te mettre à quatre pattes. Tu vas sucer son pénis et on va te pénétrer. Soumets-toi !**