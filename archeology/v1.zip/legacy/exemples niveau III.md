# exemples niveau III
- langue

Phrases enchâssées, questions, mots d'amour, temps complexes.

> O gais oi rao.
> Elir yuda sen, ao ora li yun ?
> A djiloda es ora mi if feoda ?
> A yu to rao moon. Aa lapa "I mi moon, neihem. E fen feo om em yuni bo."
> Elem sen, o ora io tar yun.
> Elem sen, o ora iolir tar yun.
> Elem a yu la yun, aolir tar yin odom. Aolem ora dom.
> Do gais mu ?
> A yunoda ora dur ?
> Co rao.
> Elem i toda li yun, neo fo gais.
> Elem a yu la yun, ao tar yin odom. Aolem ora dom.
> Elir kegais sente, oi gais rao.
> Omgatar rao yinom.