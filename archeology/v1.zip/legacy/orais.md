# orais
- verbe **jouir**

De *ora gais* (excitation de l'esprit).

> Orais.         **Jouis.**
> A yoda orais.  **Jouis avec elle.**