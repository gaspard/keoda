# mu
- verbe **tirer avec la main**
- chose **tension**

Du suffixe *u* (**tirer**) et de *ma* (**main**). Se prononce « mou ».

> A mu djil.	  **Tire-lui les cheveux.**
> O neo mu gais.  **Ça me fatigue.**
> O gais mu.      **Je me sens tendu, fatigué.**