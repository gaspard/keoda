# peu
- adjectif **peureux**
- chose    **peur**
- verbe.   **avoir peur**

Se prononce "pe ou".

> Djiloda peu dome.  **La personne aux cheveux est assez  
> 					 peureuse.**
> I peu.