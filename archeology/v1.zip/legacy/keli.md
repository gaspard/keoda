# keli
- corps **langue**
- verbe **lécher**

Provient de *ke* (caché par) et *li* (bouche).

> Olir keli moon    **On va te lécher les seins**
> La keli           **Embrasse ma langue**