# z i
- suffixe **caresser**
- préfixe **à toi**

Il y a une exception pour le suffix ajouté à *ma*, la **main**. Dans ce cas, on ne dit pas “mani” mais directement *mi*.

> Mi oda. **Masse-moi le corps.**
> A mi moon. **Masse-lui/elle les seins.**
> I mi yon. **Masse-toi la vulve.**
> Hafbaji oda. **Caresse mon corps avec ta cuisse.**
> Olir i ma tar. **On va se masturber.**