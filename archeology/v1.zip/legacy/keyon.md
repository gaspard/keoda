# keyon
- corps **clitoris**

Littéralement **caché par la vulve**.

> Li keyon.		**Suce mon clitoris.**