# rao
- corps **coeur**
- verbe **aimer**
- adjectif **tendrement**

> Raohem.  **Mon amour, mon coeur.**

Pour faire la différence entre "aimer le pénis" et "aimer pénétrer", on doit utiliser les mots d'adresse (*o*, *i*, *a*, *oi*, *io*). Par exemple:

> Io rao tar. **À toi, j'aime le pénis.**  
>   **J'aime ton pénis.**
> O rao i tar yin. **J'aime, à toi, pénétrer le vagin.**  
>   **J'aime te baiser.**
> O rao oi tar yun. **J'aime, à moi, tu pénétrer la vulve.**  
>   **J'aime que tu me baises.**

Voici d'autres exemples.

> Rao yun.       **Aime ma vulve.**
> I rao.         **Aime-toi.**
> Rao.           **Aime-moi.**
> O rao tar.     **J'aime mon pénis.**
> Io rao tar.    **J'aime ton pénis.**

On a la même chose avec les verbes *ora* (désirer), *gais* (sentir), etc.

> Gais rao.        **Sens mon coeur.**
> I gais rao.      **Sens ton coeur.**
> Gais io rao.     **Sens mon amour.**
> Io gais rao.     **Je sens ton coeur.**
> Io gais oi rao.  **Je sens ton amour (pour moi).**
> Io gais i rao.   **Je sens ton amour (pour toi).**
> O ora i mi moon. **Ça m'excite quand tu te carresses les seins.**