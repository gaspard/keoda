# sat
- corps **pied**
- position **debout**
- todo