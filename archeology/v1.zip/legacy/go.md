# go
- chose **gode, vibro**
- verbe **pénétrer avec un gode**

> Olir go yin. **On va te pénétrer le vagin avec un gode.**
> Yoda olir go kepal.