# fa

- corps **yeux**
- verbe **regarder**, **montrer**

Lorsqu’on utilise les yeux comme "récépteurs" d'un gest, ça veut dire montrer sauf si on utilise un des suffixes comme (i, u ou o). Par exemple _ma fa_ veut dire "montre ta main" mais _mi fa_ veut dire "caresse mes yeux".

> Fa tar. **Regarde mon pénis**
> Ma fa. **Montre ta main** (ta main dans mes yeux)
> Lir moon fa. **Tu vas montrer tes seins**
> Mi fa. **Caresse mes yeux**
> Fa lo. **Tu pleures** (yeux humides)
> Ne fa. **Ferme les yeux** (pas yeux)
