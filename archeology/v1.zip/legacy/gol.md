# gol
- adjectif **grand**

Voir aussi *lil* (petit).

> O ora i tar gol.  **Je désire à toi, le grand pénis.**