# oi
- langue **à moi, tu**

Concaténation de *o i*. La forme non raccourcie, n'est pas usitée. Cette forme qui est le défaut d'une phrase n'est utilisé que pour les enchâssées. Se prononce "oï" et pas "o-i".

Voir aussi *io* **à toi, je**.

> O rao oi tar yun.  **J'aime que tu me baises.**

Dire *Oi hafbaji bo* n'est pas faut mais ce n'est pas utilisé, on dira *Hafbaji bo*.

> (Oi) Hafbaji bo.     **Caresse mon ventre avec tes cuisses.**