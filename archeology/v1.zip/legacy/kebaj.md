# kebaj
- corps **testicule**

De **caché par les jambes**.

> La kebaj es.  **Embrasse mon testicule gauche.**
> Kebaj la.     **Mets tes testicules sur ma bouche.**