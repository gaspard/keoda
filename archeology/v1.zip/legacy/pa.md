# pa
- adjectif **partout**
- chose **l’univers, le tout**
- suffixe **partout**

Voir *lipa* (chanter), *lapa* (parler).

> Fen pa.  **Danse partout.**
> Lem pa. **Aie de la tendresse pour tout.**