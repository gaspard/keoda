# don
- verbe **faire, bouger**

Ce prononce "donne". Il peut aussi être utilisé pour l’éxecution de tâches préparées avec *lir*.

> Ne don.  **Ne bouge pas.**
> Lir la hafmoon menu… Don.**Tu vas m’embrasser délicatement les tétons…. Fais-le.**