# ne
- verbe **enlever**
- adjectif **négation**
- prefix**négation**

Le "e" se prononce comme dans "mais".

> Ne feoda. **Enlève tes habits.**
> Ne fa. **Ferme les yeux.**
> Ne femoon. **Enlève ce qui couvre tes seins.**
> E kat ne fehafoda. **Mets-toi à quattre pattes, le torse nu.**
> Nema sat. **Lâche mon pied.**