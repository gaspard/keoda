# toda
- corps **corps avec un pénis**

Désigne une personne qui nous semble porter un pénis. Diminutif de *taroda* (voir suffixe *oda*).

> Ora toda li tar ?     **Tu aimerais lui sucer le pénis ?**
> Ora toda o tar yin melo ?  
>   **Tu aimerais qu'il te pénètre doucement ?**
> Toda ud mo pal.          **(à lui en face) donne la fessée.**