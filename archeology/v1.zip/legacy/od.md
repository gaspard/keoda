# od
- corps **dos**
- position **allongé sur le dos**

Avec l’ajout *yon* on *tar*, la personne est allongée sur le dos, le bassin tendu, le dos arqué. Tout le poids est sur les épaules et les pieds.

> E od om.	  **Soit allongée sur le dos, les jambes écartées.**
> E odtar im. **Soit sur les épaules et les pieds cambré, le  
> 				pénis en avant.**