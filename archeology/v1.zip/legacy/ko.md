# ko

- préfixe **avec**

> Ko yin li tar. **Suce mon pénis avec ton vagin.**
> Ko i. **Avec toi = bonjour, salutation.**
> Ko ioda. Co igais. Co iora. **Variantes de salutation affichant des intentions.**
