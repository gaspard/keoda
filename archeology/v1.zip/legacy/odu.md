# odu
- verbe **venir, aller**

De **tirer le corps**.

> Odu sen. **Viens ici.**
> Odu ud. **Viens en face de moi.**
> A to odu ud. **Va en face de lui.**
> I odu es. **Va sur ta gauche.**
> A djiloda odu. **Va vers la personne aux cheveux.**