# fen
- corps **genoux**
- verbe **danser** (non, danser, c'est les hanches)
- position **à genoux, le buste dressé**

> Fen bo.    **Danse avec le ventre.**
> Fenoda.    **Danse avec tout ton corps**
> E fen lo.  **Soit à genoux, soumise.**
> E fenbo.   **Soit à genoux, les jambes en L, le ventre en  
> 			 avant.**