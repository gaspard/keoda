# kiss
- chose **chaise**

> E pal tole sat fe kiss.  
> 	**Assieds-toi sur la table, les pieds sur la chaise.**