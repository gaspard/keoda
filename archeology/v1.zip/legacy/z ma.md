# z ma
- corps **main**
- verbe **prendre dans la main**, **branler**, **tenir**

Voir aussi les exceptions liées au suffixes *i* et *o*, *mi* **masser** et *mo* **frapper, faire mal**. On peut aussi utiliser la négation *nema* ** lâcher**.

> Ma tar.       **Prends mon pénis dans ta main.**
> Ma tar melo.  **Branle-moi doucement.**
> Nema feyon. **Lâche ta culotte.**