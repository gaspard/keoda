# hafmoon
- corps **tétons**
- verbe **jouer des tétons**

Littéralement **tête des seins**.

> Hafmoon la.	**Amène tes tétons sur mes lèvres.**