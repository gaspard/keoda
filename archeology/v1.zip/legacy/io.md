# io
- langue **à toi, je**

Concaténation de *i o*. La forme non raccourcie, n'est pas usitée. On peut aussi avoir *iolir* (à toi, je vais). Se prononce "yo" (court) et pas "i-o".

Voir aussi *oi* **à moi, tu**.

> O rao io tar yun.  **J'aime te baiser.**
> Iolir fo pal.      **À toi, je vais fouetter les fesses.**