# corao
- langue **merci**

> Corao, gafo.