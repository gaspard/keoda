# il
- corps **oreille**
- verbe **écouter**

> O rao io il rao.  **J'aime écouter ton coeur.**
> Il lapa. **Écoute ma voix.**

> Il lapa. A yunoda taroda rao moon.