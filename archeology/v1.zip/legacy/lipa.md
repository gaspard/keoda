# lipa
- verbe **chanter**