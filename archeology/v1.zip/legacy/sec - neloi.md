# sec ? neloi ?

- todo

Humide se dit _loi_.

ash = feu (chaud)
nash = nuage (from fire)

loi = humide

dur ?
té ?

mou ?
mé ?

kelité kelimé
