# yin

- corps **vagin**
- verbe **prendre dans le vagin**

On peut penser à la différence entre _yon_ et _yin_ comme à celle entre _la_ (lèvres) et _li_ (bouche). Le rond du "o" de yon ressemble aux grandes lèvres, le point du "i" au col mystérieux entre le vagin et l'utérus.

> Yin haftar. **Suce mon gland de ton vagin.**
> Yodalir go yin odom.  
>  **Elle va te pénétrer avec un gode hyper fort.**
