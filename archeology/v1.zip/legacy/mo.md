# mo
- verbe **frapper, faire mal** (avec la main)

De *ma* (**main**) avec le suffixe *o* (**frapper, faire mal**). Ne pas confondre avec *fo* (**fouetter**). Voir aussi *mu* (**tirer**).

> Olir mo pal dom.   **On va te donner la fessée, bien fort**
> Mo yon menu.       **Frappe ma vulve avec la main,  
>                    délicatement**