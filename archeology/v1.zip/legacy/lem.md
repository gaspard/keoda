# lem

- suffixe **du passé**

> Miau. **Fais-moi un câlin.**

Permet d'exprimer des événements passés.

> Faodalem li tar dom. **La personne aux yeux du passé m'a sucé le pénis bien fort.**
