# sen

- chose **ici**
- verbe **être présent**
- adjectif **présent**
- position **au pied**

Se prononce "senne". Voir aussi _ud_, _no_, _es_, _we_.

Quelle est la différence entre _Sen_ (Soit présent, donne-moi ta présence) et _I gais oda_ (Sens-toi) ?

_Sen_ implique une forme de yoga de la conscience, une ouverture non-focalisée. On pourrait aussi exprimer une idée similaire avec _Gais pa_ (Sent tout) ou encore _Gais pa sen_ (Sent tout ce qui est ici) mais l'expression _Sen_ est un peu différente. Elle implique un don: _Sen_ se traduit littéralement par _À moi, donne ta présence_. Voir aussi _Rao_ (_Donne-moi ton amour_).

_I gais oda_ implique une focalisation de l'attention sur le corps. On pourrait dire aussi _I gais bo_ (Sent ton ventre), etc.

> Sen. **Donne-moi ta présence.**
> Odu sen. **Viens ici.**
> E sen. **Soit au pied.**
