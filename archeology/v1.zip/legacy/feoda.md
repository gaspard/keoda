# feoda
- chose **habits**
- adjectif **habillé**

Vient de *fe* (**couvrir, sur**) et *oda* (**corps, énergie**).

> E feoda. **Habille-toi.**
> Ne feoda. **Déshabille-toi.**
> A yo mi yon feoda. **À la personne avec vulve, caresse la vulve sur les habits.**
> E fen if toda. **Mets-toi à genoux sur la personne avec un pénis.**