# em
- préfixe **et**

Permet de joindre deux phrases.

> E fen om em olir hafma yin.  
> 	**Mets-toi à genoux, les cuisses écartées et on va peut-être  
> 	  te doigter.**