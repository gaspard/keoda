# neo
- chose **chose**

De *ne oda* (qui n'a pas de vie).

> A neo mo.   **Frappe ça.**
> Neo nei.    **C'est joli.**