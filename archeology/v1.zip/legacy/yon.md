# yon
- corps **vulve**
- verbe **embrasser avec la vulve**

Merveille des merveilles, *yon* est le sexe féminin dans toute sa splendeur. Le clitoris se dit *keyon*, le vagin *yin*.

> Yon tar.		**Embrasse mon pénis avec ta vulve.**
> O tar yon.	**On embrasse ta vulve avec notre pénis.**
> A ud falir yon.		  
> 	**Tu vas montrer ta vulve à la personne en face de toi.**