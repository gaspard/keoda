# du
- préfix **en bas**

On peut nommer toutes sortes de parties du corps ainsi. Par exemple:

> Ne feduoda. **Dénude la partie inférieure du corps.**
> La dubo. **Embrasse mon pubis (partie inférieur du ventre).**
> Olir no dubaj. **On va t’attacher les chevilles.**
> Mi dupal. **Masse-moi le périné.**