# meu
- préfixe **sinon**

Très important: permet de menacer.

> A yoda li yon ora meu i fo pal.  
> 	**Suce-lui la vulve en l’excitant (bien) ou on te fouette  
> 	  les fesses.**