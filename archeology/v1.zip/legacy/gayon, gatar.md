# gayon, gatar
- chose **salope**

Littéralement **qui pense avec sa vulve/son pénis**.

> Gatar.    **Salope !**
> Gayon.    **Salope !**
> Gayin.    **Salope profonde !**
> Gahaftar. **Salope sensuelle !**
> Gakeyon.  **Salope sensuelle !**