# ba
- verbe **danse**, **deviens ce mouvemen**, **mouvement**

Ce verbe est utilisé pour imposer une danse et doit être compris comme “deviens cette danse”. Une danse implique beaucoup plus qu’une succession de postures: c’est une disponibilité, une manière d’être à la chose dansée, un abandon.

Les mouvements de danse étants difficiles à décrire, il faudra faire des vidéos.

> Ba kat.            **À quatre pattes, la danse du petit chien joyeux qui bat de la queue: il faut trouver le rythme adapté et doux pour le dos et le bassin, ça doit respirer le cul content.**