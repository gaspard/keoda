# we
- adjectif **à droite**
- verbe **tourner à droite**

Dans la famille des adjectifs de localisation, il y a aussi *ud* (**devant**), *no* (**derrière**) et *es* (**gauche**).

Pour rappel, les adjectifs se placent toujours après.

> Fa moon we.       **Montre ton sein droite.**
> Mi kebaj we.      **Caresse mon testicule droite.**
> We.               **Tourne à droite, plus à droite.**