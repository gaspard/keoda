# rim
- corps **poignets**
- verbe **attacher**
- position **à genoux, les poignets offerts**

> I yodalir rim. **La personne à la vulve va t’attacher.**
> Fa rim.		 **Montre tes poignets.**
> E rim od.		 **Mets les poignets dans le dos.**
> E rim.	     **Soit à genoux les poignets offerts.**