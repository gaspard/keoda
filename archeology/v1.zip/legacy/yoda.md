# yoda
- corps **corps avec vulve**

Permet de désigner une personne que nous supposons posséder une vulve. Diminutif de *yonoda*. On peut de même dire *moonoda* pour **personne avec des seins** (voir suffixe *oda*) selon l’accent que l’on veut mettre sur certaines parties du corps.

> Ora yoda mi moon ?  
>   **à cette personne, tu caresserais les seins ?**
> Ora yoda o li tar ?  
>   **tu aimerais que cette personne te suce le pénis ?**
> yoda lilir yon  
>   **à cette personne, tu vas sucer la vulve**