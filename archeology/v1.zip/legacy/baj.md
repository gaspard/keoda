# baj
- corps **jambe**

On obtient aussi **cuisse** avec *hafbaj* ou **testicules** avec *kebaj*.