# no
- chose **corde**
- verbe **attacher**

> I rim od. Olir no.		**Mets tes poignets dans ton dos, je  
> 						vais t'attacher.**