# li
- corps **bouche**
- verbe **sucer**

Plus profond qu’embrasser (*la*). La profondeur ou intensité peut être ajoutée par un adjectif (*dom*, *menu*).

> Li keyon melo.     **Suce mon clitoris doucement**
> Li tar.            **Suce mon pénis**