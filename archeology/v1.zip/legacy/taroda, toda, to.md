# taroda, toda, to
- chose *il*

Littéralement *la personne avec un pénis*. Comme avec toutes les personnes, on peut abréger en ne gardant que le *..o* final.

> A to la la. **Embrasse-le sur la bouche.**
> I tolem li yun. **Il te suça la vulve.**  
>  **À toi, la personne au pénis du passé suce la vulve.**
> Tolir li kepal. **Il va me sucer l'anus.**