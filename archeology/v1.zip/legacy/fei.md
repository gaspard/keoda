# fei
- adjectif **sur toi**

De *fe* (sur) et *i* (à toi). Voir aussi *feo* (sur moi).

> Yodalir e fen fei om. **Elle sera à genoux sur toi, ouverte.**