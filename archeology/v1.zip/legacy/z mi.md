# z mi
- verbe **masser**

De *ma* (**main**) avec le suffixe *i* (**masser**).

> Mi oda        **Masse-moi le corps, partout**
> Olir mi pal   **On va te masser les fesses**
> I mi moon     **Masse-toi les seins**