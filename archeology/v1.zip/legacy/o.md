# o
- suffixe **frapper, faire mal**
- préfix **à nous**
- langue **on**
- todo 

Il y a une exception pour le suffix ajouté à *ma*, la **main**. Dans ce cas, on ne dit pas “mano” mais directement “mo”.

> Taro yon melo.   **Frappe doucement ma vulve avec ton pénis**
> Olir mo pal.     **On va te donner la fessée**

Au niveau de la langue *o* désign le **on** indéfinit qui représente la ou le groupe de personnes dominantes.

> Oi mi oda. **À nous, tu masses le corps.**

Dans l’exemple simple ci-dessus, le *oi* est implicite et on dira alors plus souvent:

> Mi oda. **Masse-nous le corps.**

Lorsque l’on veut désigner une action que l’on fait nous-même, on dira:

> Io mi oda. **À toi, on masse le corps.**

Et ici on simplifiera en:

> O mi oda. **À toi (implicite), on masse le corps.**
> Faodalir mi baj. **À toi (implicite), la personne aux yeux va masser la jambe.**

Le cas un peu particulier de l’exhibition forcée (on te met à nu pour nous montrer ton corps) avec *fa* est intéressant. Comment dit-on “on va te montrer notre verge” versus “on va exhiber ta verge” ?

La différence est marquée par le préfixe *o* sur la partie du corps:

> Olir fa otar. **À toi (implicite), on va montrer notre verge**
> Olir fa tar. **À toi (implicite), on va exhiber la verge**