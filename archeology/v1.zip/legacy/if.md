# if
- adjectif **sous**

> Mi bo if feoda.  **Caresse mon ventre sous mes habits.**
> Odu if oda.      **Viens sous moi.**
> Elem o if yoda, o orais dom.  
>                  **Quand j'étais sous elle, j'ai bien jouis.**