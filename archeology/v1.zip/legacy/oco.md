# oco
- langue **comme**

À la manière de, comme. Se place après le verbe ou le complément.

> Li hafma oco tar. **Suce mon doigt comme si c'était un pénis.**
> Yin oco li tar. **Baise mon pénis avec ton vagin comme si tu le suçait.**