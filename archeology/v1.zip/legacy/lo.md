# lo
- adjectif **soumis(e)**
- todo