# do
- langue **interrogation**

Transforme un impératif en interrogation. Se place juste avant le verbe.

> Gais rao.      **Sens mon coeur.**
> Do gais rao ?  **Sens-tu mon coeur ?**
> A toda ilem do orais ?  **Tu as jouis avec lui ?**