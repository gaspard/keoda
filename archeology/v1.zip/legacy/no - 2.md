# no
- adjectif **arrière**
- verbe **reculer**

Dans la famille des adjectifs de localisation, il y a aussi *ud* (**devant**), *es* (**gauche**) et *we* (**droite**).

Pour rappel, les adjectifs se placent toujours après.

> Olir fo oda no.   **On va te fouetter l'arrière du corps.**
> Mi no bo.         **Caresse mon ventre du dos de la main.**
> No.               **Recule.**