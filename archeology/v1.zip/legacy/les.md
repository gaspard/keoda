# les
- verbe **payer**
- préfixe **payer pour**

De là vient *lesoda* (la personne qu’on paie pour son corps) ou encore *lespal* (la personne qu’on paie pour son cul).

> Yodalir lesyin tar.    **Elle va payer pour te baiser.**
> Todalir lestar kepal.  **Il va payer pour te sodomiser.**
> Les.					 **Paie.**
> Odu sen, lesoda lil.    **Viens ici petite pute.**