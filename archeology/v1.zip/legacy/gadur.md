# gadur
- chose **soumise**

De *gais dur* (qui pense à la soumission). Voir aussi *gafo* (maître).

> E kat om, gadur hem. **À quatre pattes, ma soumise.**