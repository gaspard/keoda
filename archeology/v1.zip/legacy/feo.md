# feo
- adjectif **sur moi**

De *fe* (sur) et *o* (je). Voir aussi *fei* (sur toi).

> E fen feo em lir yinu tar.  
>   **Soit à genoux sur moi puis tu tireras sur mon pénis avec ton vagin.**