# fo
- verbe **fouetter**

> Olir fo oda no.	**On va te frapper l’arrière du corps.**
> Om meu o fo hafbaj.  
> 	**Écarte sinon on te fouette les cuisses.**