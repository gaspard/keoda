# sente
- verbe **arriver**


> Kegais sente. **Les dieux arrivent.**