# hem
- préfixe **offert**

Permet de signifier à la personne soumise qu’elle ou une partie d’elle est offerte, possédée, ne lui appartient plus. C’est un signe d’appréciation important, un des meilleurs compliments. Ce compliment souligne l’abandon, la confiance et la puissance qui en découle.

Se prononce "hème" (avec un "h" sonore).

> Tarhem. **Ton pénis est offert (à nous, à moi, à eux).**
> Moonhem. **Tes seins sont offerts**
> Lihem. **Tu es notre suceur / suceuse.**
> Liyun, raohem. **Suce ma vulve, coeur offert.**

*Odahem* est une expression d’admiration devant un corps qui se donne. Comparé au suffix *om*, *hem* est plus humain, on sent l’effort et la concentration de la personne dans son “don”, *hem* est un peu plus actif que *om* qui traduit plus un état d’être, une disponibilité.