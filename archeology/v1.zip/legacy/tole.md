# tole

- chose **table**

> E pal tole hafbaj om.  
>  **Assieds-toi sur la table les cuisses écartées.**
> E sat tole. **Soit debout sur la table.**
> E ma tole. **Mains sur la table.**
