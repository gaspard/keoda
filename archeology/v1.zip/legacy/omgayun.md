# omgayun
- chose **dieu de la vulve, Parvati**

Si l'on connaît *gayun* (qui pense avec sa vulve, salope), ainsi que *om* (transcendance), on peut comprendre *omgayun*: **qui transcende la pensée issue de la vulve**, déesse du sexe féminin. Voir aussi *yinom* (le vagin sacré, temple féminin).