# es
- adjectif **à gauche**
- verbe **tourner à gauche**

Dans la famille des adjectifs de localisation, il y a aussi *ud* (**devant**), *no* (**derrière**) et *we* (**droite**).

Pour rappel, les adjectifs se placent toujours après.

> Fa ma es.         **Montre ta main gauche.**
> Mi moon es.       **Caresse mon sein gauche.**
> Es.               **Tourne à gauche, plus à gauche.**