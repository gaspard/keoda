# omgatar rao yinom
- chant

*Omgatar rao yinom*  
*Omgatar rao yinom*  
*Kegais ! Kegais hem !*
*Kegais ! Kegais hem !*
*Odu sen. Odu sen.*

