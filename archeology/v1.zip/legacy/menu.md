# menu
- adjectif **délicatement**

De la manière la plus douce, la plus subtile possible. Le “u” se prononce “ou” comme dans “fou”. 

> Yon tar menu. **Effleure mon pénis avec ta vulve, comme si  
>                   tu l’embrassait de tes lèvres**

Voir aussi *melo* **doucement**.