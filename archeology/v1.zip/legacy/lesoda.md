# lesoda
- chose **pute**

Littéralement, **la personne qu’on paie pour son corps**.

> Lesodahem.           **Ma pute.**
> Odu sen, lesoda lil. **Viens ici petite pute.**