# Elem
- préfixe **quand dans le passé...**

Pour dire **quand tu ...**, on devrait dire *Elem ilem...* mais on simplifie avec *Elem*. De même pour *Elem yodalem* qui devient *Elem yoda*. De plus *Elem e* (quand tu étais) est remplacé par *Elem* tout seul.

> Elem sen, o ora iolir tar yun.  
> **Quand tu étais ici, j'aurais aimé te pénétrer.**
> Elem fen, rao i mi hafbaj.  
> **Quand tu étais à genoux, tu as aimé te caresser les cuisses.**
> Elem a yu la yun, ao tar yin odom. Aolem ora dom.  
> **Quand, à elle, tu embrassais la vulve, à elle je baisais le vagin à fond. En relation avec elle, ma personne du passé était très excitée.**  
> **Quand tu lui embrassais la vulve, je la baisais à fond et j'étais très excité.**
> Elem yoda sen, olem peu oalir fo od. Olem peu dom.  
> **Quand elle était ici, j'avais peur qu'elle me fouette le dos. J'avais très peur.**