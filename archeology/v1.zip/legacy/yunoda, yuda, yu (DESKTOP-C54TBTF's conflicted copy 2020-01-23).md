# yunoda, yuda, yu
- chose **elle**
- todo **remplacer yo par yu et yoda par yuda**

Littéralement **la personne avec une vulve**. Peut être abrégée *yu*.

> A yu yuda no baj. **À elle, elle attache les jambes.**
> I yulir fo pal.   **À toi, la personne à la vulve du futur va fouetter les fesses.**
> Yuda yun la.    **Elle pose sa vulve sur mes lèvres.**