# lapa
- corps **voix**
- verbe **parler**

Vient de *la* (lèvres) et *pa* (partout).

> Lapa ora.	**Dis-moi ton niveau d’excitation.**
> Il lapa. **Écoute ma voix.**