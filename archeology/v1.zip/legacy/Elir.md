# Elir
- préfixe **quand dans le futur**

De même que pour *Elem*, on ne dira pas *Elir ilir* ou *Elir yodalem* mais simplement *Elir* et *Elir yoda*.

> Elir yoda sen, ao mi pal fe feoda.