# fe
- préfixe **sur**

On obtient ainsi *feoda* (habits, litt. "sur le corps") mais on peut aussi dire sur les habits *fe feoda* ou encore *fe tole* (sur la table), etc.

> A toda ma tar feoda.  
>   **Masturbe-le habillé.**
> A nedjiloda ma tar fe feoda.  
>   **Au chauve, masturbe son sexe par-dessus les habits.**