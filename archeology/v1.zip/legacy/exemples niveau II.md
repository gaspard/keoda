# exemples niveau II
- langue

Passé, futur, avec, comme, salutations.

> Oco ora, gafo.
> Yinu tar dom meu io(lir) fo od.
> A yudalir mu djil.
> Co ioda.
> Co i.
> Yin oco li tar.
> Li hafma oco tar.
> A to co yu li tar.
> Co fo mi moon.
> A fo pal.
> E pal tole sat fe kiss im.
> E moon pal odom.
> Yulem oco Sati yun tar.
> I yulir fo pal.