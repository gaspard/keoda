# ay, at
- langue raccourci de *A yunoda* et *A taroda*

Permet de faire référence aux personnes impliquées dans la phrase précédente sans répéter leur noms complets. De même *u* reprend le sujet de la phrase précédente.

> A yoda toda rao moon. Ay u lapa "I mi moon, neihem. E fen feo om em yuni bo."  
> **Un gars aime les seins d'une fille. Il lui dit "Caresse-toi les seins ma jolie. Mets-toi à genoux sur moi, les jambes écartées et caresse mon ventre avec ta vulve.**