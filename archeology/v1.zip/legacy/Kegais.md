# Kegais
- chose **dieux**
- verbe **sentir l'invisible**

Se prononce "ké ga ïss" (caché dans l'esprit). Il n'y a pas de théologie claire sur l'existence d'un ou de plusieurs dieux ni sur leur forme ou leur aspect, etc. Dieux est une expérience vécue de "ce qui est caché derrière ou dans l'esprit". Il peut s'agir de l'esprit d'une autre personne ou le sien propre.

> O kegais.   **On sent les dieux.**
> I kegais.   **Sent l'invisible en toi.**
> Io kegais.  **On sent l'invisible en toi.**
> Kegais.     **Sent l'invisible en moi.**
> Kegais sen. **Les dieux sont là.** ou **Sent l'invisible ici.**
> Elir kegais sente, oi gais rao.  **Quand les dieux arriveront, tu sentiras mon amour.**