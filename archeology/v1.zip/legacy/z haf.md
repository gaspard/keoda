# z haf
- corps **tête**
- préfixe **partie supérieure**

Par exemple, le gland se dit *haftar* (haut du pénis), le buste se dit *hafoda* (haut du corps).

> Fa hafba im       **Montre tes cuisses fermées !**
> Fa haf lo         **Montre ta tête soumise !**
> E od sat hafba om **Mets-toi sur le dos, les pieds contre les  
>                     cuisses, jambes écartées**