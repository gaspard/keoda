# gafo
- chose **dominant, maître**

De *gais fo* (qui pense au fouet). Voir aussi *gadur* (soumise).

> Oco ora, gafo. **Comme tu désires, maître.**