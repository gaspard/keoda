# co i
- langue **salutation**

Litt. **avec toi**.

> Co ioda. **Avec ton corps. (envie de jouer avec ton corps).**
> Co iora. **Avec ton excitation...**
> Co igais. **Avec ton esprit. (envie d'échanger).**

Quelle que soit la forme utilisée, c'est un compliment, une envie d'être en présence, d'échanger.