# lil
- adjectif **petit**
- position **en boule**

Voir aussi *gol* (grand).

> Lesoda lil.          **Petite pute.**
> A liloda ora mi bo.  **À la petite personne, tu veux caresser  
> 					   le ventre ?**