# omgatar
- chose **dieu du pénis, Shiva**

Du préfixe *om*, transcendance et *gatar*, qui pense avec son pénis: **celui qui a transcendé la pensée issue du pénis**.