# bo
- corps **ventre**
- position **allongé sur le ventre**

> E bo im. Olir tar yin odom.  
> 	**Soit allongée sur le ventre les jambes fermées, je vais  
> 	pénétrer ton vagin bien fort.**
> E fenbo.  
> 	**Soit à genoux, le ventre en avant (les jambes en L).**