# fo gais
- chose **jalousie**
- verbe **rendre jaloux**

Litt. "fouetter l'esprit"

> Fo gais.  **Tu me rends jaloux.**
> Elem i toda li yun neo fo gais. **Quand il me suçait la vulve, ça t'a rendu jaloux.**