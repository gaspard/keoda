# gais
- corps **esprit**
- verbe **sentir, attendre**
- adjectif **avec esprit, avec âme**
- prefixe **qui pense avec**

Se prononce "ga iss". De là vient *gatar* (salaud, cochon), *gayon* ou *gadjil*, *gamoon*, etc.

> Gais.		  **Attends.**
> Gais yin.   **Sens mon vagin.**
> Lipa gais.  **Chante avec âme.**