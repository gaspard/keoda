# keoda
- langue          **L’énergie cachée** ou  
	                **Langue cachée du corps**

Cette langue est créée et réservée pour le sexe. Toute personne formée (*Laoda*) désirant la transmettre doit demander la permission à l’auteur **Bumagy** et doit être en relation sexuelle avec la personne à enseigner. Cette dernière devra signer un accord de non-divulgation avant d’apprendre cette langue.

L’enseignement se fait en interaction sexuelle afin de conserver l’*oda*. La personne qui reçoit l’enseignement doit obéir aux ordres et les pratiquer. C’est une langue qui doit parler au corps.

La personne, une fois formée sera testée par l’auteur (les ordres de l’auteur sont à exécuter sur le formateur) en présence de ce dernier et pourra être inscrite sur le registre des initiés à *Keoda* et devient *Laoda* (qui parle).

Une personne formée peut parler (elle est même encouragée à le faire) de l’existence de *Keoda* mais ne doit pas révéler la langue elle-même. Dans un environnement de jeu public (en groupe ou dans un donjon), un *Laoda* peut donner des ordres à sa ou son soumis mais ne doit en aucun cas traduire, expliquer ou chercher à transmettre *Keoda* aux autres participants. Ces derniers peuvent entendre cette langue en actes, sans plus.