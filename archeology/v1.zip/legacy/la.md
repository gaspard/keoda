# la
- corps **lèvres**
- verbe **embrasser**
- adjectif **fière**

Embrasser est plus léger que sucer (*li*). Pas profond. Voir aussi *lapa*.

> La ma             **Embrasse ma main**
> Ala la            **Embrasse sa main (à elle/lui)**
> La la             **Embrasse ma bouche**

L’adjectif **fier** peut modifier la position (par exemple en redressant la tête). Il est l’opposé de *lo*, **soumise**.

> E katim la        **Mets-toi à quatre pattes, fière**