# ud
- adjectif **en face, devant**
- verbe **avancer**

Dans la famille des adjectifs de localisation, il y a aussi *no* (**arrière**), *es* (**gauche**) et *we* (**droite**).

Pour rappel, les adjectifs se placent toujours après.

> Ora yona ud mi moon ?  
>   **Tu voudrais (à la fille en face) caresser les seins ?**
> Ora toda udes li haftar ?  
>   **Tu voudrais (au gars en face) sucer le gland ?**
> Ud.   **Avances.**