# im
- verbe **fermer, resserrer**
- adjectif **fermé**

Implique principalement les organes génitaux et la position des jambes, des fesses etc en lien avec ces derniers. Voir aussi *om* (**ouvert**).

> E moon im     **Soit à genoux, les seins au sol, jambes et fesses fermées**