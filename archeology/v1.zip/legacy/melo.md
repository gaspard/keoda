# melo
- adjectif **doucement**

> Mo keli melo. **Avec ta main, tire ma langue doucement.**

Voir aussi *dom* **très fort**, *menu* **délicatement** ou *gais* **avec esprit**.