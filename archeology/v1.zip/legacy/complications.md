# complications
- todo

Quelques phrases complexes...

> Elem sen, o ora io tar yun.  
> **Quand tu étais ici, ça m'excitait de te pénétrer.**
> Elem sen, o ora iolir tar yun.  
> **Quand tu étais ici, ça m'aurait excité de te pénétrer.**
> Elem a yo la yun, aolir tar yin odom. Aolem ora dom.  
> **Quand, à elle, tu embrassais la vulve, à elle j'aurais pu baiser le vagin à fond. En relation avec elle, ma personne du passé était très excitée.**  
> **Quand tu embrassais sa vulve, j'aurais pu la baiser à fond. J'étais très excité par elle.**